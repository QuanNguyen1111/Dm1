package com.qlshopquanaonhom6.shoponline.ultil;

public class Server {
    public static String localhost = "quang2002.000webhostapp.com";
    public static String DuongdanLoaisp = "http://" + localhost + "/index/getloaisp.php";
    public static String Duongdansanphammoinhat = "http://" +localhost + "/index/getsanphammoinhat.php";
    public static String Duongdandienthoai = "http://" +localhost + "/index/getsanpham.php?page=";
    public static String Duongdandonhang = "http://" + localhost + "/index/thongtinkhachhang.php";
}
