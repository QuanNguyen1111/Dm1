package net.tapetee.model.post

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class WpPostType {

    @SerializedName("href")
    @Expose
    var href: String? = null

}
