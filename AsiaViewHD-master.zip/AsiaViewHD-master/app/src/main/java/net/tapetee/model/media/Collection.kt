package net.tapetee.model.media

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Collection {

    @SerializedName("href")
    @Expose
    var href: String? = null

}
