package net.tapetee


class Constants {

    companion object {
        const val GET_ALBUM = "https://photoslibrary.googleapis.com/v1/albums/"
        const val GET_ALBUM_LIST = "https://photoslibrary.googleapis.com/v1/albums/"
    }
    
}

