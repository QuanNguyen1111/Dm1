package com.example.asm;

import android.content.ClipData;

public class Item {

    private String imageUrl, tags,The_Loai_Do;
    private int likes;

    public Item(String imageUrl, String tags, String the_Loai_Do, int likes) {
        this.imageUrl = imageUrl;
        this.tags = tags;
        this.The_Loai_Do = the_Loai_Do;
        this.likes = likes;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getThe_Loai_Do() {
        return The_Loai_Do;
    }

    public void setThe_Loai_Do(String the_Loai_Do) {
        this.The_Loai_Do = the_Loai_Do;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }
}
