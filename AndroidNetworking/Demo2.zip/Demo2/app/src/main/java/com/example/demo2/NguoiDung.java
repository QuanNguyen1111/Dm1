package com.example.demo2;

public class NguoiDung {
    int id;
    int userId;
    String title;
    String body;

    public NguoiDung(int id, int userId, String title, String body) {
        this.id = id;
        this.userId = userId;
        this.title = title;
        this.body = body;
    }
}
